package com.company;
import java.awt.*;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.TimeUnit;
public class Main {
    //подсчет соседей
    public static void next(Vector<Rect> Rct, double x) {
        Random rnd = new Random();//дебагинг :)
        int count = 0;
        System.out.println(Rct.size());//тоже :)
        for (int i = 0; i < Rct.size(); i++) {
            //Вот тут вопрос №1)
            }
        }


//Создание поля из "пустых" клеток
    public static Vector<Rect> draw(double x, double y){
        Vector<Rect> Rct = new Vector<Rect>();
        int index = 0;//длина вестора(количество клеток)
        for (double i = 0; i < x-1; i+=2) {
            for (double k = 0; k < y-1; k+=2) {
                Rct.addElement(new Rect(i+1.5, k+1.5, 1, 1));
                Rct.get(index).instantiate();
                index++;
                }
            }
        return Rct;
        }
    public static void main(String[] args) {
        double x = 129;
        double y = 63;
        StdDraw.setCanvasSize(1300, 640);
        StdDraw.setXscale(0, x);
        StdDraw.setYscale(0, y);
        StdDraw.setPenRadius(0.0001);
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.enableDoubleBuffering();
        while (true)
        {
            next(draw(x,y), x);
            StdDraw.show();
            //ограничение по фпс 1:1
            try {
                TimeUnit.SECONDS.sleep( 1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            StdDraw.clear();

        }
    }
}
